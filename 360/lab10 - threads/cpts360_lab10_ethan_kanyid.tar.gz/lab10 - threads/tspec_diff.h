#include <time.h>

double tspecDiff(struct timespec tspecStart, struct timespec tspecEnd);
