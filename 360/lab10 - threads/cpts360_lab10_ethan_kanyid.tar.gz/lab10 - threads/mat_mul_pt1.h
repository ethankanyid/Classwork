void mat_mul(double *_c, const int n, const int m,
             const double *_a, const int p, const double *_b);
