SINGLE

error https://wsu.zoom.us/j/5635500668
error http://www.tricity.wsu.edu/~bobl
okay https://remote.tricities.wsu.edu
okay https://www.tricity.wsu.edu/cs/cslab.html
error https://www.youtube.com/watch
okay http://www.tricity.wsu.edu/this_link_does_not_exist
error https://wsu.edu/covid-19
error https://communitystandards.wsu.edu/policies-and-reporting/academic-integrity-policy
error http://www.tricity.wsu.edu/disability
okay https://oem.wsu.edu/emergency-procedures/active-shooter
okay https://oem.wsu.edu/about-us
okay https://provost.wsu.edu/classroom-safety

real	0m2.053s
user	0m0.174s
sys	    0m0.063s


PARALLEL

okay https://remote.tricities.wsu.edu
okay http://www.tricity.wsu.edu/this_link_does_not_exist
error http://www.tricity.wsu.edu/~bobl
error http://www.tricity.wsu.edu/disability
okay https://provost.wsu.edu/classroom-safety
okay https://oem.wsu.edu/emergency-procedures/active-shooter
okay https://www.tricity.wsu.edu/cs/cslab.html
okay https://oem.wsu.edu/about-us
error https://communitystandards.wsu.edu/policies-and-reporting/academic-integrity-policy
error https://wsu.edu/covid-19
error https://www.youtube.com/watch
error https://wsu.zoom.us/j/5635500668

real	0m1.829s
user	0m0.337s
sys	    0m0.131s
