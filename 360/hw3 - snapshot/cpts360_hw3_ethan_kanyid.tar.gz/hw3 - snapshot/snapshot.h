extern int snapshot(char *ssname, char *progpath, char *readme);
