#include <stdio.h>

int main(void)
{
    printf("/* this is not really a C comment! */\n");
    return 0;
}
