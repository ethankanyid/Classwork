#include <stdio.h>

int main(void)
{
    printf("// this is not a C++ comment, either!\n");
    return 0;
}
